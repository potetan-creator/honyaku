local compile = loadstring or load
local source = '=[SMODS _ "src/game_object.lua"]'

local function release_function(line, declaration)
    return assert(compile(string.rep("\n", line - 1) .. declaration, source))()
end

local function attach_fixture()
    local calls = {draw = 0, send_vars = 0, present = 0, update = 0}
    local draw = release_function(3554, "return function() fixture_calls.draw = fixture_calls.draw + 1 end")
    local send_vars = release_function(3566, "return function() fixture_calls.send_vars = fixture_calls.send_vars + 1 end")
    local predicate = release_function(3584, "return function() return not G.recording_mode or G.video_control end")
    local geometry = {width = 1920, height = 1080}
    G.STAGES, G.STAGE, G.SHADERS = {RUN = 1, MENU = 2}, 1, {CRT = geometry}
    local shader = {key = "CRT", shader = "CRT", should_apply = predicate, draw = draw, send_vars = send_vars}
    SMODS.ScreenShaders = {CRT = shader}
    SMODS.ScreenShader = {obj_table = SMODS.ScreenShaders, obj_buffer = {"CRT"}}
    fixture_calls = calls

    return {
        shader = shader, original = predicate, calls = calls,
        step = function()
            calls.update = calls.update + 1
            for _, key in ipairs(SMODS.ScreenShader.obj_buffer) do
                local registered = SMODS.ScreenShaders[key]
                if not registered.should_apply or registered:should_apply() then
                    registered:send_vars()
                    registered:draw()
                end
            end
            calls.present = calls.present + 1
        end
    }
end

return function(test, close, Mock)
    test("draw and update durations have separate series and blind-window slices", function()
        local world = Mock.new()
        love.draw = function()
            world.advance(0.045)
            return nil, "drawn", nil
        end
        local runtime = world:load()
        G.blind_select = {}
        G.FUNCS.select_blind()
        world:tick()
        local _, result = love.draw()
        assert(result == "drawn")
        close(runtime.metrics.update.max, 15)
        close(runtime.metrics.draw.max, 45)
        close(runtime.metrics.blind_draw.max, 45)
        assert(world:write_report():find("love.draw elapsed", 1, true))
    end)

    test("opt-in skips exactly the CRT callbacks in runs and is independent of diagnosis", function()
        local world = Mock.new({mod_count = 50, config = {enable_monitoring = false}})
        local fixture = attach_fixture()
        local runtime = world:load()
        local crt = BalatroFrameGuard_runtime.crt
        assert(not runtime.active and fixture.shader.should_apply == fixture.original)
        fixture.step()
        crt:set_enabled(true)
        fixture.step()
        assert(crt:status() == "active" and crt.bypassed == 1)
        assert(fixture.calls.draw == 1 and fixture.calls.send_vars == 1)
        assert(fixture.calls.update == 2 and fixture.calls.present == 2)
        crt:set_enabled(false)
        assert(fixture.shader.should_apply == fixture.original)
        fixture.step()
        assert(fixture.calls.draw == 2 and fixture.calls.present == 3)
    end)

    test("CRT uses normal behavior in menu, recording and video-control modes", function()
        local world = Mock.new({config = {disable_crt_in_run = true}})
        local fixture = attach_fixture()
        world:load()
        local crt = BalatroFrameGuard_runtime.crt
        G.STAGE = G.STAGES.MENU
        fixture.step()
        G.STAGE, G.recording_mode = G.STAGES.RUN, true
        fixture.step()
        assert(fixture.calls.draw == 1)
        G.video_control = true
        fixture.step()
        assert(fixture.calls.draw == 2 and crt.bypassed == 0)
    end)

    test("a second screen shader or modified builtin stops CRT bypass alone", function()
        local world = Mock.new({config = {disable_crt_in_run = true}})
        local fixture = attach_fixture()
        local runtime = world:load()
        local crt = BalatroFrameGuard_runtime.crt
        assert(crt:status() == "active")
        SMODS.ScreenShader.obj_buffer[2] = "Other"
        SMODS.ScreenShaders.Other = fixture.shader
        fixture.step()
        assert(crt:status() == "conflict" and fixture.shader.should_apply == fixture.original)
        assert(fixture.calls.draw == 2 and runtime.active)
        SMODS.ScreenShader.obj_buffer[2] = nil
        fixture.shader.draw = function() end
        crt:set_enabled(true)
        assert(crt:status() == "conflict" and fixture.shader.should_apply == fixture.original)
    end)

    test("CRT defers to a replacement callback, a different shader instance or version", function()
        local world = Mock.new({config = {disable_crt_in_run = true}})
        local fixture = attach_fixture()
        world:load()
        local crt = BalatroFrameGuard_runtime.crt
        local retained = fixture.shader.should_apply
        fixture.shader.should_apply = function(self) return retained(self) end
        local new_owner = fixture.shader.should_apply
        fixture.step()
        assert(crt:status() == "conflict" and fixture.shader.should_apply == new_owner)
        fixture.shader.should_apply = fixture.original
        crt:set_enabled(true)
        G.SHADERS.CRT = {}
        assert(crt:status() == "conflict" and fixture.shader.should_apply == fixture.original)
        SMODS.version = "0.0.0"
        crt:set_enabled(true)
        assert(crt:status() == "unsupported" and fixture.shader.should_apply == fixture.original)
    end)

    test("config toggle and report show CRT independently", function()
        local world = Mock.new({config = {enable_monitoring = false}})
        attach_fixture()
        world:load()
        local toggle = assert(world.mod.config_tab().nodes[3].toggle)
        assert(toggle.ref_value == "disable_crt_in_run")
        toggle.ref_table[toggle.ref_value] = true
        toggle.callback(true)
        local report = world:write_report()
        assert(report:find("CRT bypass requested=true | state=active", 1, true))
        assert(report:find("Monitoring requested=false | running=false", 1, true))
    end)
end

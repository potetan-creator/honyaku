-- Optional integration fixture. Pass a local checkout of Steamodded 26.1002.0.
local directory = assert(arg[1], "Pass the Steamodded 26.1002.0 source directory")
local compile = loadstring or load
local function read(path)
    local file = assert(io.open(directory .. "/" .. path, "rb"))
    local content = file:read("*a")
    file:close()
    return content:gsub("\r\n", "\n")
end

local shaders = read("src/game_object.lua")
local first = assert(shaders:find("    SMODS.ScreenShaders = {}", 1, true))
local finish = assert(shaders:find("\n        should_apply = function(self) return not G.recording_mode or G.video_control end,", first, true))
local last = assert(shaders:find("\n    }", finish, true))
local _, lines_before = shaders:sub(1, first - 1):gsub("\n", "")
local excerpt = shaders:sub(first, last + #"\n    }" - 1)

local pipeline = read("lovely/screenshader_rendering.toml")
local start = assert(pipeline:find("local last_canvas = self.CANVAS", 1, true))
local ending = assert(pipeline:find("\n'''", start, true))
local render = assert(compile("return function(self)\n" .. pipeline:sub(start, ending - 1) .. "\nend"))()

local trace = {}
local function count(entry)
    trace[entry] = (trace[entry] or 0) + 1
end
local canvas = {getPixelHeight = function() return 1080 end}
local gpu_shader = {send = function() count("uniform") end}
love = {graphics = {
    setCanvas = function() end, setShader = function() end, clear = function() end,
    draw = function(texture)
        if texture == canvas then count("drawSource") else count("drawIntermediate") end
    end
}}
G = {
    VERSION = "1.0.1o-FULL", STAGE = 1, STAGES = {RUN = 1},
    SHADERS = {CRT = gpu_shader}, CANVAS = canvas, CANV_SCALE = 1,
    TILESIZE = 10, TILESCALE = 1, ARGS = {eased_cursor_pos = {sx = 0, sy = 0}},
    SETTINGS = {GRAPHICS = {crt = 0, bloom = 1}}, TIMERS = {REAL = 0}
}
SMODS = {
    version = "26.1002.0", create_canvas = function() return {} end,
    GameObject = {extend = function(_, class)
        return setmetatable(class, {__call = function(self, object)
            setmetatable(object, {__index = self})
            self.obj_table[object.key] = object
            self.obj_buffer[#self.obj_buffer + 1] = object.key
        end})
    end}
}
assert(compile(string.rep("\n", lines_before) .. excerpt, '=[SMODS _ "src/game_object.lua"]'))()
local crt = dofile("src/crt.lua").new(SMODS)
render(G)
assert(trace.uniform == 11 and trace.drawSource == 1 and trace.drawIntermediate == 1)
trace = {}
crt:set_enabled(true)
assert(crt:status() == "active")
render(G)
assert(trace.uniform == nil and trace.drawSource == 1 and trace.drawIntermediate == nil)
assert(crt.bypassed == 1)
crt:set_enabled(false)
trace = {}
render(G)
assert(trace.uniform == 11 and trace.drawIntermediate == 1)
print("PASS Steamodded 26.1002.0 render payload: 11 uniform sends + 2 draws → 0 sends + 1 draw → restored")

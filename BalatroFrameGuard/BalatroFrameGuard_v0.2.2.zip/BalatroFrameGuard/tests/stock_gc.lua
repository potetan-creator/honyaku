-- Read the original function from a separately supplied Balatro 1.0.1o source
-- snapshot. The snapshot is not part of this distribution.
local function load_stock_gc(directory)
    local file = assert(io.open(directory .. "/functions/misc_functions.lua", "rb"))
    local source = file:read("*a"):gsub("\r\n", "\n")
    file:close()
    local text = assert(source:match("(function nuGC%b().-\nend)"))
    local compile = loadstring or load
    assert(compile(text, "@functions/misc_functions.lua"))()
    return assert(nuGC)
end

return load_stock_gc

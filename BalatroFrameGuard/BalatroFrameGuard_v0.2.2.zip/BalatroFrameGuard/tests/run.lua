local Mock = dofile("tests/mock.lua")

local passed = 0
local function test(name, fn)
    local ok, err = pcall(fn)
    if not ok then error(name .. ": " .. tostring(err), 0) end
    passed = passed + 1
    io.write("PASS ", name, "\n")
end

local function close(actual, expected)
    assert(math.abs(actual - expected) < 0.001, tostring(actual) .. " ~= " .. tostring(expected))
end

local function collect_returns(...)
    return select("#", ...), {...}
end

test("vanilla-shaped progress, score, state, RNG and event order", function()
    local reference = Mock.new():progress()
    local measured = Mock.new()
    local runtime = measured:load()
    assert(runtime.active)
    assert(measured:progress() == reference)
    assert(runtime.metrics.points.events.count == 5)
    assert(runtime.metrics.points.blind_set.count == 1)
    assert(runtime.metrics.points.draw_dispatch.count == 1)
    assert(runtime.metrics.points.score.count == 1)
    assert(runtime.metrics.points.shop_update.count == 1)
    assert(runtime.metrics.points.shop_leave.count == 1)
    assert(measured.writes == 0)
end)

test("50 mock mods register and preserve all chained calls", function()
    local base = Mock.new({mod_count = 50})
    local expected = base:progress()
    local measured = Mock.new({mod_count = 50})
    measured:load()
    assert(measured:progress() == expected)
    assert(measured.registered_calls == base.registered_calls and measured.registered_calls == 250)
    assert(measured:write_report():find("Count=51", 1, true))
    assert(measured.report:find("MockMod50 1.0.0", 1, true))
end)

test("raw delta, game dt and inclusive update wall time are separate", function()
    local world = Mock.new()
    local runtime = world:load()
    local count, returned = collect_returns(world:tick(0.160, 0.05))
    assert(count == 3 and returned[1] == nil and returned[2] == "game" and returned[3] == nil)
    close(world.forwarded_dt, 0.05)
    close(runtime.metrics.frame_gap.max, 160)
    close(runtime.metrics.game_dt.max, 50)
    close(runtime.metrics.update.max, 15)
    assert(#runtime.metrics.recent == 1)
    assert(runtime.metrics.recent[1].id == "frame_gap")
    assert(runtime.metrics.memory.count == 1)
end)

test("blind window records fresh set, draw dispatch and nested time union", function()
    local world = Mock.new()
    local runtime = world:load()
    world:progress()
    local m = runtime.metrics
    assert(m.blind_windows == 1 and m.blind_sets == 1 and m.blind_draws == 1)
    assert(m.blind_selections == 1 and m.blind_fallbacks == 0)
    assert(m.blind_gap.count == 4 and m.blind_update.count == 4)
    assert(m.blind_set_latency.count == 1 and m.blind_draw_latency.count == 1)
    close(m.coverage.sum, 117)
    close(m.coverage.covered, 92)
    close(m.coverage.uncovered, 25)
    assert(m.points.events.blind_count == 4)
end)

test("a long stall crossing the entire blind window is still recorded", function()
    local world = Mock.new()
    local runtime = world:load()
    world.queue(function()
        G.blind_select = {}
        G.FUNCS.select_blind()
        world.advance(3)
    end)
    world:tick()
    world.delta = 3.1
    world.advance(0.085)
    love.update(0.05)
    assert(runtime.metrics.blind_update.max > 3000)
    close(runtime.metrics.blind_gap.max, 3100)
end)

test("missing select hook falls back to fresh blind setup, excluding reset", function()
    local world = Mock.new()
    G.FUNCS.select_blind = nil
    local runtime = world:load()
    Blind:set_blind({label = "silent"}, nil, true)
    Blind:set_blind(nil, true, nil)
    assert(runtime.metrics.blind_windows == 0)
    Blind:set_blind({label = "fresh"})
    assert(runtime.metrics.blind_windows == 1 and runtime.metrics.blind_fallbacks == 1)
    assert(runtime.hooks.by_id.blind_select.status == "unsupported")
end)

test("rings are bounded, totals survive wrap, nearest-rank sample counts", function()
    local world = Mock.new({config = {max_events = 3, frame_samples = 128, slow_update_ms = 10000}})
    local runtime = world:load()
    for i = 1, 300 do world:tick(i / 1000) end
    local count, total, max, n, p50, p95, p99 = runtime.metrics.frame_gap:summary()
    assert(count == 300 and n == 128 and #runtime.metrics.recent == 3)
    close(total, 45150)
    close(max, 300)
    close(p50, 236)
    close(p95, 294)
    close(p99, 299)
    local report = world:write_report()
    local a = assert(report:find("300.000ms (threshold", 1, true))
    local b = assert(report:find("299.000ms (threshold", 1, true))
    assert(a < b)
end)

test("disabled at boot does no per-update clock reads or wrapper calls", function()
    local world = Mock.new({config = {enable_monitoring = false}})
    local runtime = world:load()
    local reads = world.reads
    assert(not runtime.active and love.update == world.originals.love_update)
    assert(Game.update == world.originals.game_update and G.FUNCS.select_blind == world.originals.select)
    world:progress()
    assert(world.reads == reads and runtime.metrics.update.count == 0)
end)

test("config UI, threshold editing, no stacking, reset and re-enable", function()
    local world = Mock.new()
    local runtime = world:load()
    local installed = love.update
    dofile("main.lua")
    assert(love.update == installed and BalatroFrameGuard_runtime.runtime == runtime)
    local root = world.mod.config_tab()
    assert(root.nodes[1].toggle.label == "診断を有効にする")
    local toggle = root.nodes[1].toggle
    local cycles = root.nodes[7].nodes
    local choice = cycles[1].nodes[1].cycle
    G.FUNCS[choice.opt_callback]({cycle_config = choice, to_val = "25"})
    assert(world.mod.config.slow_update_ms == 25)
    toggle.ref_table[toggle.ref_value] = false
    toggle.callback(false)
    assert(love.update == world.originals.love_update)
    toggle.ref_table[toggle.ref_value] = true
    toggle.callback(true)
    world:tick()
    assert(runtime.metrics.update.count == 1)
    G.FUNCS.bfg_frameguard_reset()
    assert(runtime.metrics.update.count == 0 and runtime.metrics.memory.count == 0)
    assert(runtime.startup.first_update ~= nil)
    world:tick()
    assert(runtime.metrics.update.count == 1)
end)

test("missing or conflicting UI controls leave other controls usable", function()
    local world = Mock.new()
    world:load()
    create_option_cycle = nil
    local foreign = function() end
    G.FUNCS.bfg_frameguard_reset = foreign
    assert(world.mod.config_tab().n == G.UIT.ROOT)
    assert(G.FUNCS.bfg_frameguard_reset == foreign)
    assert(world:write_report():find("Balatro FrameGuard 0.2.2", 1, true))
end)

test("reset or toggle from inside update does not attach stale timing", function()
    local world = Mock.new()
    local runtime = world:load()
    world.queue(function() runtime:reset() end)
    world:tick()
    assert(runtime.metrics.update.count == 0 and runtime.metrics.coverage.count == 0)
    world:tick()
    assert(runtime.metrics.update.count == 1 and runtime.metrics.coverage.count == 1)
    world.queue(function() runtime:set_enabled(false) end)
    world:tick()
    assert(runtime.metrics.update.count == 1 and love.update == world.originals.love_update)
    runtime:set_enabled(true)
    world:tick()
    assert(runtime.metrics.update.count == 2)
end)

test("after-load conflicting hook preserves replacement and disables only itself", function()
    local world = Mock.new()
    local runtime = world:load()
    local retained, calls = G.FUNCS.select_blind, 0
    local replacement = function(...)
        calls = calls + 1
        return retained(...)
    end
    G.FUNCS.select_blind = replacement
    G.blind_select = {}
    G.FUNCS.select_blind()
    assert(calls == 1 and runtime.metrics.points.blind_select.count == 0)
    assert(runtime.hooks.by_id.blind_select.status == "conflict")
    world:tick()
    assert(runtime.metrics.update.count == 1)
    runtime:set_enabled(false)
    runtime:set_enabled(true)
    assert(G.FUNCS.select_blind == replacement)
end)

test("non-chaining overwrite and callback table changes appear in ownership audit", function()
    local world = Mock.new()
    local runtime = world:load()
    local unrelated = function() end
    G.FUNCS.evaluate_play = unrelated
    world:tick()
    assert(runtime.hooks.by_id.score.status == "conflict" and G.FUNCS.evaluate_play == unrelated)
    local old = G.FUNCS
    G.FUNCS = {select_blind = unrelated}
    world:write_report()
    assert(runtime.hooks.by_id.blind_select.status == "conflict")
    assert(G.FUNCS.select_blind == unrelated and old.select_blind == world.originals.select)
end)

test("original errors propagate with exact object and measurement can recover", function()
    local world = Mock.new()
    local token = {}
    local should_error = true
    G.FUNCS.evaluate_play = function(a, b, c)
        assert(a == "first" and b == nil and c == 3)
        if should_error then error(token) end
        return nil, "ok", nil
    end
    local runtime = world:load()
    local ok, err = pcall(G.FUNCS.evaluate_play, "first", nil, 3)
    assert(not ok and err == token)
    should_error = false
    local count, returned = collect_returns(G.FUNCS.evaluate_play("first", nil, 3))
    assert(count == 3 and returned[2] == "ok")
    assert(runtime.metrics.points.score.count == 1 and runtime.metrics.points.score.errors == 1)
end)

test("same-hook recursion and yieldable coroutine bypass preserve values", function()
    local world = Mock.new()
    G.FUNCS.evaluate_play = function(value)
        if value == "co" then return coroutine.yield(nil, "paused", nil) end
        if value == 0 then return nil, 7, nil end
        return G.FUNCS.evaluate_play(value - 1)
    end
    local runtime = world:load()
    local count, returned = collect_returns(G.FUNCS.evaluate_play(2))
    assert(count == 3 and returned[2] == 7)
    local co = coroutine.create(function() return G.FUNCS.evaluate_play("co") end)
    local ok, nil_value, message = coroutine.resume(co)
    assert(ok and nil_value == nil and message == "paused")
    ok, message = coroutine.resume(co, "resumed")
    assert(ok and message == "resumed")
    assert(runtime.metrics.points.score.count == 1)
    assert(runtime.metrics.points.score.recursive_skips == 2)
    assert(runtime.metrics.points.score.coroutine_skips == 1)
end)

test("instrumentation fault stops one hook while preserving original call", function()
    local world = Mock.new()
    local runtime = world:load()
    local original_before = runtime.before
    runtime.before = function(self, entry, ...)
        if entry.spec.id == "blind_select" then error("observer fault") end
        return original_before(self, entry, ...)
    end
    G.blind_select = {}
    G.FUNCS.select_blind()
    assert(world.trace[1] == "select")
    assert(runtime.hooks.by_id.blind_select.status == "fault")
    assert(G.FUNCS.select_blind == world.originals.select)
    world:tick()
    assert(runtime.metrics.update.count == 1)
end)

test("clock missing or regressing fails open and raw dt failure stays separate", function()
    local world = Mock.new({no_clock = true})
    local runtime = world:load()
    assert(runtime.clock_status == "unsupported" and not runtime.active)
    assert(world:write_report():find("monotonic clock=environment unsupported", 1, true))
    world = Mock.new({no_delta = true})
    runtime = world:load()
    world:tick()
    world:tick()
    assert(runtime.metrics.frame_gap.count == 0 and runtime.metrics.fallback_gap.count == 1)
    world.now = world.now - 3
    world:tick()
    assert(runtime.clock_status == "fault" and not runtime.active)
    assert(love.update == world.originals.love_update)
    world = Mock.new()
    runtime = world:load()
    world:tick()
    love.timer.getDelta = function() error("unavailable") end
    world:tick()
    assert(runtime.delta_status == "fault")
    assert(runtime.metrics.frame_gap.count == 1 and runtime.metrics.fallback_gap.count == 1)
end)

test("manual report filters paths, claims no culprit, and tolerates write failures", function()
    local world = Mock.new()
    local runtime = world:load()
    local other = world.add_mod("unsafe\nC:/private/name", "C:/private/version")
    other.description = "SECRET_SAVE_SEED"
    local disabled = world.add_mod("AbsentMock", "5")
    disabled.disabled = true
    world:tick()
    assert(world.writes == 0)
    world.filesystem.write = function() error("read only") end
    world:write_report()
    world.filesystem.write = function(name, data) world.report_name, world.report = name, data; return true end
    local report = world:write_report()
    assert(world.report_name == "frameguard-report.txt")
    assert(report:find("unknown unknown", 1, true))
    assert(report:find("responsible mod are unknown", 1, true))
    assert(not report:find("private", 1, true) and not report:find("SECRET", 1, true))
    assert(not report:find("AbsentMock", 1, true))
    assert(runtime.active)
end)

test("invalid config normalization and independently unavailable optimization flags", function()
    local world = Mock.new({config = {
        enable_monitoring = "false", max_events = 9000, frame_samples = -1,
        slow_update_ms = 0 / 0, large_frame_gap_ms = 0, blind_window_seconds = math.huge,
        enable_gc_tuning = "true", enable_optional_cache = true
    }})
    world:load()
    local config = world.mod.config
    assert(config.enable_monitoring == true and config.slow_update_ms == 40 and config.large_frame_gap_ms == 1)
    assert(config.max_events == 1000 and config.frame_samples == 128 and config.blind_window_seconds == 2)
    assert(not config.enable_gc_tuning and not config.enable_optional_cache)
end)

dofile("tests/crt.lua")(test, close, Mock)
dofile("tests/gc.lua")(test, close, Mock)

io.write(("%d mock tests passed (%s)\n"):format(passed, jit and jit.version or _VERSION))

return function(test, close, Mock)
    test("GC timing works with an unrecognized collector and leaves arguments and returns intact", function()
        local world = Mock.new({config = {enable_gc_tuning = true}})
        local calls = 0
        nuGC = function(budget, ceiling, stop)
            assert(budget == nil and ceiling == nil and stop == true)
            calls = calls + 1
            world.advance(0.060)
            return nil, "gc", nil
        end
        local update = Game.update
        Game.update = function(...)
            local function check(count, first, second, third)
                assert(count == 3 and first == nil and second == "gc" and third == nil)
            end
            local function returns(...) check(select("#", ...), ...) end
            returns(nuGC(nil, nil, true))
            return update(...)
        end
        local runtime = world:load()
        -- As in the user's log, Game:update has been replaced, but still runs.
        local wrapped = Game.update
        Game.update = function(...) return wrapped(...) end
        world:tick(0.060)
        world:tick(0.080)
        assert(calls == 2 and runtime.gc:status(true) == "unsupported")
        assert(runtime.gc:status(false) == "active")
        assert(runtime.hooks.by_id.game_update.status == "conflict")
        close(runtime.metrics.gc.max, 60)
        assert(runtime.metrics.gc.linked_majority_gaps == 1)
        local report = world:write_report()
        assert(report:find("Worst logged gap", 1, true))
        assert(report:find("previous update nuGC=60.000 ms (1 calls)", 1, true))
        assert(runtime.metrics.worst_gap.gc_calls == 1)
        local gc_before = runtime.metrics.gc.count
        runtime:set_enabled(false)
        world:tick()
        assert(runtime.metrics.gc.count == gc_before)
    end)

    test("GC hook forwards to replacements and preserves original error values", function()
        local world = Mock.new()
        local token = {}
        local original = function() error(token) end
        nuGC = original
        local runtime = world:load()
        local retained = nuGC
        local ok, err = pcall(nuGC, nil, nil, true)
        assert(not ok and err == token and runtime.metrics.gc.count == 0)
        local next_hook = function(...) return retained(...) end
        nuGC = next_hook
        ok, err = pcall(nuGC, nil, nil, true)
        assert(not ok and err == token)
        assert(runtime.gc:status(false) == "conflict")
        runtime:set_enabled(false)
        assert(nuGC == next_hook)
    end)

    test("GC linkage survives log rotation for the worst blind-window gap", function()
        local world = Mock.new({config = {max_events = 1}})
        nuGC = function() world.advance(0.060) end
        local update = Game.update
        Game.update = function(...)
            nuGC(nil, nil, true)
            return update(...)
        end
        local runtime = world:load()
        G.blind_select = {}
        G.FUNCS.select_blind()
        world:tick()
        world:tick(0.080)
        assert(runtime.metrics.worst_blind_gap.gc_calls == 1)
        world.advance(5)
        world:tick(0.150)
        assert(not runtime.metrics.recent[1].blind)
        local report = world:write_report()
        assert(report:find("Worst blind-window gap", 1, true))
        assert(report:find("80.000ms | previous update nuGC=60.000 ms", 1, true))
        runtime:reset()
        assert(runtime.metrics.worst_blind_gap.ms == nil)
    end)
end

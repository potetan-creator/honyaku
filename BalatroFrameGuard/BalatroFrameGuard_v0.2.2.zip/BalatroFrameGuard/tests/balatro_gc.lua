-- Exercise the runtime wrapper with the actual stock nuGC body and fake clock.
local source_dir = assert(arg[1], "Pass a Balatro 1.0.1o source snapshot directory")
local real_collect = collectgarbage
local stock = dofile("tests/stock_gc.lua")(source_dir)
local clock, heap, steps, full, stops = 0, 0, 0, 0, 0
love = {timer = {getTime = function()
    clock = clock + 1
    return clock / 10000
end}}
collectgarbage = function(mode)
    if mode == "step" then steps = steps + 1 end
    if mode == "collect" then full = full + 1 end
    if mode == "stop" then stops = stops + 1 end
    if mode == "count" then return heap end
end
G = {VERSION = "1.0.1o-FULL", STAGES = {RUN = 1, MENU = 2}, STAGE = 1}
local runtime = {config = {enable_gc_tuning = true}, active = false, read_heap = function() return heap end}
local gc = dofile("src/gc.lua").new(runtime)
gc:refresh()
assert(gc:status(true) == "active")

heap = 127 * 1024
nuGC(nil, nil, true)
assert(gc.tuned_calls == 0)
heap = 128 * 1024
nuGC(nil, nil, true)
assert(gc.tuned_calls == 1 and full == 0)
steps, full, stops = 0, 0, 0
heap = 300 * 1024 + 1
stock(nil, nil, true)
local baseline_steps = steps
steps, full, stops = 0, 0, 0
nuGC(nil, nil, true)
assert(steps > baseline_steps and full == 1 and stops == 1 and gc.tuned_calls == 2)

nuGC(0.0003, nil, true)
nuGC(nil, 250, true)
nuGC(nil, nil, false)
nuGC(nil, nil, true, nil)
assert(gc.tuned_calls == 2)
G.STAGE = G.STAGES.MENU
nuGC(nil, nil, true)
assert(gc.tuned_calls == 2)
G.STAGE = G.STAGES.RUN
local co = coroutine.create(function() nuGC(nil, nil, true) end)
assert(coroutine.resume(co))
assert(gc.tuned_calls == 2)

runtime.config.enable_gc_tuning = false
gc:refresh()
assert(nuGC == stock and gc:status(true) == "disabled")
collectgarbage = real_collect
print("PASS Balatro 1.0.1o stock GC: 0.8 ms budget, original full GC and stop conditions preserved")

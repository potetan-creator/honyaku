local Crt = {}
Crt.__index = Crt

-- Reviewed against Steamodded 26.1002.0, src/game_object.lua.
local source = '=[SMODS _ "src/game_object.lua"]'
local function from_release(fn, line)
    if type(fn) ~= "function" or type(debug) ~= "table" or type(debug.getinfo) ~= "function" then
        return false
    end
    local ok, info = pcall(debug.getinfo, fn, "S")
    return ok and info and info.source == source and info.linedefined == line
end

local function default_pipeline(class, registry)
    local keys = class.obj_buffer
    return type(keys) == "table" and keys[1] == "CRT" and keys[2] == nil
        and class.obj_table == registry
end

function Crt.new(smods)
    return setmetatable({smods = smods, state = "disabled", bypassed = 0}, Crt)
end

function Crt:stop(state)
    if self.object and rawget(self.object, "should_apply") == self.wrapper then
        rawset(self.object, "should_apply", self.original)
    end
    self.object, self.wrapper, self.original, self.owns_pipeline = nil, nil, nil, nil
    self.state = state
end

function Crt:matches(class, registry, object, gpu_shader, draw, send_vars)
    local g = G
    return type(g) == "table" and type(g.SHADERS) == "table" and g.SHADERS.CRT == gpu_shader
        and self.smods.ScreenShader == class and self.smods.ScreenShaders == registry
        and registry.CRT == object and default_pipeline(class, registry)
        and object.key == "CRT" and object.shader == "CRT" and object.path == nil
        and object.mod == nil and not object.taken_ownership
        and object.draw == draw and object.send_vars == send_vars
end

function Crt:status()
    if self.state == "active" and not self.owns_pipeline() then
        self:stop("conflict")
    end
    return self.state
end

function Crt:set_enabled(enabled)
    if not enabled then
        self:stop("disabled")
        return
    end
    if self:status() == "active" then return end
    local g, smods = G, self.smods
    if smods.version ~= "26.1002.0" or type(g) ~= "table"
            or (g.VERSION ~= "1.0.1o-FULL" and g.VERSION ~= "1.0.1o")
            or type(g.SHADERS) ~= "table" or not g.SHADERS.CRT then
        self.state = "unsupported"
        return
    end
    local class, registry = smods.ScreenShader, smods.ScreenShaders
    if type(class) ~= "table" or type(registry) ~= "table" or type(registry.CRT) ~= "table" then
        self.state = "unsupported"
        return
    end

    local object, gpu_shader = registry.CRT, g.SHADERS.CRT
    local original = rawget(object, "should_apply")
    local draw, send_vars = object.draw, object.send_vars
    if not self:matches(class, registry, object, gpu_shader, draw, send_vars)
            or not from_release(original, 3584) or not from_release(draw, 3554)
            or not from_release(send_vars, 3566) then
        self.state = "conflict"
        return
    end

    local wrapper
    local function owns_pipeline()
        return rawget(object, "should_apply") == wrapper
            and self:matches(class, registry, object, gpu_shader, draw, send_vars)
    end
    wrapper = function(shader, ...)
        if self.wrapper ~= wrapper then return original(shader, ...) end
        if not owns_pipeline() then
            self:stop("conflict")
            return original(shader, ...)
        end

        local current = G
        local stages = current.STAGES
        if shader == object and type(stages) == "table" and stages.RUN ~= nil
                and current.STAGE == stages.RUN and not current.recording_mode and not current.video_control then
            self.bypassed = self.bypassed + 1
            return false
        end
        return original(shader, ...)
    end

    self.object, self.wrapper, self.original = object, wrapper, original
    self.owns_pipeline, self.state = owns_pipeline, "active"
    rawset(object, "should_apply", wrapper)
end

return Crt

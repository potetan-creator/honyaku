local Metrics = {}
Metrics.__index = Metrics

local Series = {}
Series.__index = Series

function Series.new(capacity)
    return setmetatable({
        capacity = capacity, values = {}, count = 0, sum = 0, max = 0, next = 1
    }, Series)
end

function Series:add(value)
    self.count = self.count + 1
    self.sum = self.sum + value
    self.max = math.max(self.max, value)
    self.values[self.next] = value
    self.next = self.next % self.capacity + 1
end

function Series:summary()
    local sorted = {}
    for i, value in ipairs(self.values) do sorted[i] = value end
    table.sort(sorted)
    local n = #sorted
    local function percentile(fraction)
        return sorted[math.ceil(n * fraction)]
    end
    return self.count, self.sum, self.max, n, percentile(0.50), percentile(0.95), percentile(0.99)
end

function Metrics.new(config, specifications)
    local self = setmetatable({
        config = config, points = {}, recent = {}, recent_next = 1,
        blind_windows = 0, blind_selections = 0, blind_fallbacks = 0,
        blind_sets = 0, blind_draws = 0, blind_set_latency = Series.new(128),
        blind_draw_latency = Series.new(128), failed_updates = 0, dropped_gaps = 0
    }, Metrics)
    for _, name in ipairs({
        "frame_gap", "fallback_gap", "game_dt", "update", "blind_gap", "blind_fallback_gap",
        "blind_update", "draw", "blind_draw"
    }) do
        self[name] = Series.new(config.frame_samples)
    end
    for _, specification in ipairs(specifications) do
        self.points[specification.id] = {
            count = 0, sum = 0, max = 0, blind_count = 0, blind_sum = 0, blind_max = 0,
            errors = 0, coroutine_skips = 0, recursive_skips = 0
        }
    end
    self.memory = {count = 0}
    self.gc = {count = 0, sum = 0, max = 0, linked_slow_gaps = 0, linked_majority_gaps = 0}
    self.worst_gap, self.worst_blind_gap = {}, {}
    self.coverage = {count = 0, sum = 0, covered = 0, uncovered = 0}
    return self
end

local function set_observation(row, id, ms, time, blind, gc)
    row.id, row.ms, row.time, row.blind = id, ms, time, blind
    row.gc_ms, row.gc_calls, row.heap_before, row.heap_after = nil, nil, nil, nil
    if gc and gc.count > 0 then
        row.gc_ms, row.gc_calls, row.heap_before, row.heap_after = gc.ms, gc.count, gc.before, gc.after
    end
end

function Metrics:slow(id, ms, time, blind, threshold, gc)
    local slot = self.recent_next
    local row = self.recent[slot]
    if not row then
        row = {}
        self.recent[slot] = row
    end
    set_observation(row, id, ms, time, blind, gc)
    row.threshold = threshold
    self.recent_next = slot % self.config.max_events + 1
    return row
end

function Metrics:gap(id, ms, time, blind, gc)
    if ms > (self.worst_gap.ms or -1) then
        set_observation(self.worst_gap, id, ms, time, blind, gc)
    end
    if blind and ms > (self.worst_blind_gap.ms or -1) then
        set_observation(self.worst_blind_gap, id, ms, time, blind, gc)
    end
    self[id]:add(ms)
    if blind then
        local blind_series = id == "frame_gap" and self.blind_gap or self.blind_fallback_gap
        blind_series:add(ms)
    end
    if ms > self.config.large_frame_gap_ms then
        self:slow(id, ms, time, blind, self.config.large_frame_gap_ms, gc)
        if gc and gc.count > 0 then
            self.gc.linked_slow_gaps = self.gc.linked_slow_gaps + 1
            if gc.ms >= ms / 2 then
                self.gc.linked_majority_gaps = self.gc.linked_majority_gaps + 1
            end
        end
    end
end

function Metrics:gc_call(ms, time, blind, heap_before, heap_after)
    local gc = self.gc
    gc.count, gc.sum = gc.count + 1, gc.sum + ms
    if gc.count == 1 or ms > gc.max then
        gc.max, gc.max_time, gc.max_blind = ms, time, blind
        gc.max_heap_before, gc.max_heap_after = heap_before, heap_after
    end
    if ms > self.config.slow_update_ms then
        local row = self:slow("nuGC", ms, time, blind, self.config.slow_update_ms)
        row.heap_before, row.heap_after = heap_before, heap_after
    end
end

function Metrics:call(id, ms, time, blind, gc)
    local point = self.points[id]
    point.count = point.count + 1
    point.sum = point.sum + ms
    point.max = math.max(point.max, ms)
    if blind then
        point.blind_count = point.blind_count + 1
        point.blind_sum = point.blind_sum + ms
        point.blind_max = math.max(point.blind_max, ms)
    end
    if ms > self.config.slow_update_ms then
        point.last_slow_time, point.last_slow_ms, point.last_slow_blind = time, ms, blind
        point.last_slow_threshold = self.config.slow_update_ms
        self:slow(id, ms, time, blind, self.config.slow_update_ms, gc)
    end
    if id == "game_update" then
        self.update:add(ms)
        if blind then self.blind_update:add(ms) end
    elseif id == "love_draw" then
        self.draw:add(ms)
        if blind then self.blind_draw:add(ms) end
    end
end

function Metrics:cover(total, covered)
    local coverage = self.coverage
    covered = math.min(total, math.max(0, covered))
    coverage.count = coverage.count + 1
    coverage.sum = coverage.sum + total
    coverage.covered = coverage.covered + covered
    coverage.uncovered = coverage.uncovered + total - covered
end

function Metrics:heap(kib, time)
    local memory = self.memory
    memory.count = memory.count + 1
    memory.first = memory.first or kib
    memory.min = math.min(memory.min or kib, kib)
    memory.max = math.max(memory.max or kib, kib)
    memory.last, memory.time = kib, time
end

return Metrics

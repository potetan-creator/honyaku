local Hooks = {}
Hooks.__index = Hooks

local running = coroutine.running
local call = pcall
local raise = error

function Hooks.new(observer, specifications)
    local self = setmetatable({observer = observer, entries = {}, by_id = {}}, Hooks)
    for i, spec in ipairs(specifications) do
        local entry = {spec = spec, status = "disabled"}
        self.entries[i] = entry
        self.by_id[spec.id] = entry
    end
    return self
end

local function release(entry, status)
    if entry.owner and rawget(entry.owner, entry.spec.key) == entry.wrapper then
        rawset(entry.owner, entry.spec.key, entry.original)
    end
    entry.live = false
    entry.status = status
    entry.owner, entry.wrapper, entry.original = nil, nil, nil
end

function Hooks:attach(entry)
    if entry.live or entry.status == "conflict" or entry.status == "fault" then return end
    local spec, observer = entry.spec, self.observer
    local owner = spec.owner()
    local original = owner and rawget(owner, spec.key)
    if type(original) ~= "function" then
        entry.status = "unsupported"
        return
    end

    local wrapper
    local function finish(generation, start, success, ...)
        entry.busy = false
        local measured = call(observer.after, observer, entry, generation, start, success)
        if not measured then
            observer:instrumentation_failed(entry, generation)
            release(entry, "fault")
        end
        if not success then raise((...), 0) end
        return ...
    end
    wrapper = function(...)
        if not entry.live or entry.wrapper ~= wrapper then return original(...) end
        if rawget(owner, spec.key) ~= wrapper then
            release(entry, "conflict")
            return original(...)
        end
        local thread, main = running()
        if thread and not main then
            observer:skip(entry, "coroutine_skips")
            return original(...)
        end
        if entry.busy then
            observer:skip(entry, "recursive_skips")
            return original(...)
        end

        local ok, generation, start = call(observer.before, observer, entry, ...)
        if not ok then
            observer:instrumentation_failed(entry, observer.generation)
            release(entry, "fault")
        end
        if not start then return original(...) end
        entry.busy = true
        return finish(generation, start, call(original, ...))
    end

    entry.owner, entry.original, entry.wrapper = owner, original, wrapper
    entry.live, entry.status = true, "active"
    rawset(owner, spec.key, wrapper)
end

function Hooks:audit()
    for _, entry in ipairs(self.entries) do
        if entry.live and (entry.spec.owner() ~= entry.owner
                or rawget(entry.owner, entry.spec.key) ~= entry.wrapper) then
            release(entry, "conflict")
        end
    end
end

function Hooks:enable()
    for _, entry in ipairs(self.entries) do self:attach(entry) end
end

function Hooks:disable()
    for _, entry in ipairs(self.entries) do
        if entry.live then release(entry, "disabled") end
    end
end

return Hooks

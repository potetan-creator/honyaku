local Gc = {}
Gc.__index = Gc

Gc.budget_ms = 0.8
Gc.pressure_mib = 128
local budget_seconds = Gc.budget_ms / 1000
local running = coroutine.running

-- Match the stock LuaJIT nuGC from Balatro 1.0.1o. Other implementations can
-- still be timed, but are never passed an alternative budget.
local function can_tune(fn)
    local game = rawget(_G, "G")
    if type(game) ~= "table" or (game.VERSION ~= "1.0.1o-FULL" and game.VERSION ~= "1.0.1o") then
        return false
    end
    local ok, util = pcall(require, "jit.util")
    if not ok then return false end
    local info = util.funcinfo(fn)
    if not info or info.source ~= "@functions/misc_functions.lua" or info.params ~= 3
            or info.bytecodes ~= 44 or info.gcconsts ~= 8 or info.nconsts ~= 3 or info.upvalues ~= 0 then
        return false
    end
    for i, name in ipairs({"love", "timer", "getTime", "collectgarbage", "step", "count", "collect", "stop"}) do
        if util.funck(fn, -i) ~= name then return false end
    end
    return util.funck(fn, 0) == 0.0003 and util.funck(fn, 1) == 1 and util.funck(fn, 2) == 1024
end

function Gc.new(runtime)
    return setmetatable({runtime = runtime, tuned_calls = 0}, Gc)
end

function Gc:detach()
    if self.wrapper and rawget(_G, "nuGC") == self.wrapper then
        rawset(_G, "nuGC", self.original)
    end
    self.wrapper, self.original, self.compatible = nil, nil, false
end

function Gc:audit()
    if self.wrapper and rawget(_G, "nuGC") ~= self.wrapper then
        self:detach()
        self.conflict = true
    end
end

function Gc:status(tuning)
    self:audit()
    if tuning then
        if not self.runtime.config.enable_gc_tuning then return "disabled" end
    elseif not self.runtime.active then
        return "disabled"
    end
    if self.conflict then return "conflict" end
    if self.wrapper and (not tuning or self.compatible) then return "active" end
    return "unsupported"
end

local function default_run_call(budget, ceiling, stop)
    if budget ~= nil or ceiling ~= nil or stop ~= true then return false end
    local game = rawget(_G, "G")
    local stages = type(game) == "table" and game.STAGES
    return type(stages) == "table" and stages.RUN ~= nil and game.STAGE == stages.RUN
end

function Gc:refresh()
    self:audit()
    local runtime = self.runtime
    local requested = runtime.config.enable_gc_tuning
    if self.conflict or (not runtime.active and not requested) then
        self:detach()
        return
    end
    if self.wrapper then
        if not runtime.active and not self.compatible then self:detach() end
        return
    end
    local original = rawget(_G, "nuGC")
    if type(original) ~= "function" then return end
    local checked, compatible = pcall(can_tune, original)
    compatible = checked and compatible
    if not runtime.active and not compatible then return end

    local wrapper, busy
    local function finish(generation, start, heap_before, success, ...)
        busy = false
        if not success then error((...), 0) end
        runtime:after_gc(generation, start, heap_before)
        return ...
    end

    wrapper = function(...)
        if self.wrapper ~= wrapper then return original(...) end
        if rawget(_G, "nuGC") ~= wrapper then
            self:audit()
            return original(...)
        end
        local thread, main = running()
        if busy or (thread and not main) then return original(...) end

        local eligible = compatible and runtime.config.enable_gc_tuning and select("#", ...) == 3
            and default_run_call(...)
        local heap_before
        if eligible or runtime.active then heap_before = runtime:read_heap() end
        local tuned = eligible and heap_before and heap_before >= Gc.pressure_mib * 1024
        if tuned then self.tuned_calls = self.tuned_calls + 1 end

        if runtime.active then
            local start = runtime:now()
            if start then
                local generation = runtime.generation
                busy = true
                if tuned then
                    return finish(generation, start, heap_before, pcall(original, budget_seconds, nil, true))
                end
                return finish(generation, start, heap_before, pcall(original, ...))
            end
        end
        if tuned then return original(budget_seconds, nil, true) end
        return original(...)
    end

    self.original, self.wrapper, self.compatible = original, wrapper, compatible
    rawset(_G, "nuGC", wrapper)
end

return Gc

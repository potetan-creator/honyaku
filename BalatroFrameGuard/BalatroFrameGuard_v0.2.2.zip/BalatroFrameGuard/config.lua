-- Steamodded loads these defaults and merges its saved per-mod settings.
return {
    enable_monitoring = true,
    slow_update_ms = 40,
    large_frame_gap_ms = 70,
    max_events = 200,
    frame_samples = 2048,
    blind_window_seconds = 2,
    disable_crt_in_run = false,
    enable_gc_tuning = false,
    enable_optional_cache = false
}

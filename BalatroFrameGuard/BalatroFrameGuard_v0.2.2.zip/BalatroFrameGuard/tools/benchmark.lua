-- Run from the MOD folder with LuaJIT. This measures the fixture only.
local Mock = dofile("tests/mock.lua")
local config = dofile("config.lua")
local iterations = tonumber(arg[1]) or 300000
local repeats = tonumber(arg[2]) or 5
assert(iterations >= 100 and repeats >= 1)

local function heap()
    collectgarbage("collect")
    return collectgarbage("count")
end

local function run(mode)
    local options = {mod_count = 50, config = dofile("config.lua")}
    options.config.enable_monitoring = mode ~= "off"
    local world = Mock.new(options)
    local before = heap()
    local runtime = mode ~= "baseline" and world:load() or nil
    if mode == "off_after_sampling" then
        for _ = 1, config.frame_samples + 100 do world:tick(0.1) end
        runtime:set_enabled(false)
    end
    local retained = heap() - before
    for _ = 1, 5000 do world:tick() end
    local reads_before = world.reads
    local start = os.clock()
    for _ = 1, iterations do world:tick() end
    local elapsed = os.clock() - start
    return elapsed * 1000000 / iterations, retained, world.reads - reads_before
end

local modes = {"baseline", "off", "on", "off_after_sampling"}
io.write("mode,repeat,iterations,cpu_us_per_tick,retained_kib_before_timed_loop,clock_reads_in_timed_loop\n")
for repeat_number = 1, repeats do
    for offset = 0, #modes - 1 do
        local mode = modes[(repeat_number + offset - 1) % #modes + 1]
        local elapsed, retained, reads = run(mode)
        io.write(("%s,%d,%d,%.6f,%.3f,%d\n"):format(mode, repeat_number, iterations, elapsed, retained, reads))
    end
end

-- Run each mode in a separate LuaJIT process.
-- Usage from the MOD directory: luajit tools/gc_benchmark.lua SOURCE_DIR off|on FRAMES TABLES
local source_dir, mode = assert(arg[1]), assert(arg[2])
local frames, tables = assert(tonumber(arg[3])), assert(tonumber(arg[4]))
assert(mode == "off" or mode == "on")
local real_collect, clock = collectgarbage, os.clock
dofile("tests/stock_gc.lua")(source_dir)
local full = 0
collectgarbage = function(action, ...)
    if action == "collect" then full = full + 1 end
    return real_collect(action, ...)
end
love = {timer = {getTime = clock}}
G = {VERSION = "1.0.1o-FULL", STAGES = {RUN = 1}, STAGE = 1}
local runtime = {
    config = {enable_gc_tuning = mode == "on"}, active = false,
    read_heap = function() return real_collect("count") end
}
local gc = dofile("src/gc.lua").new(runtime)
gc:refresh()
assert(gc:status(true) == (mode == "on" and "active" or "disabled"))

local elapsed, gc_times = {}, {}
local peak_heap, retained = 0
for i = 1, frames do
    local frame_start = clock()
    nuGC(nil, nil, true)
    local gc_end = clock()
    local transient = {}
    for j = 1, tables do
        transient[j] = {i, j, i + j}
    end
    retained = transient
    gc_times[i] = (gc_end - frame_start) * 1000
    elapsed[i] = (clock() - frame_start) * 1000
    peak_heap = math.max(peak_heap, real_collect("count") / 1024)
end
assert(retained[tables][1] == frames)
assert(gc.tuned_calls <= frames and (mode == "on" or gc.tuned_calls == 0))
table.sort(elapsed)
table.sort(gc_times)
io.write(("%s,%d,%d,%d,%d,%.2f,%.3f,%.3f,%.3f,%.3f,%.3f\n"):format(
    mode, frames, tables, gc.tuned_calls, full, peak_heap, gc_times[math.ceil(frames * 0.95)],
    gc_times[#gc_times], elapsed[math.ceil(frames * 0.95)], elapsed[math.ceil(frames * 0.99)], elapsed[#elapsed]))

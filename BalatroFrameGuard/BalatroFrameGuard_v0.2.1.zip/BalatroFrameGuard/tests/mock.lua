-- A small Steamodded-shaped environment run from the root of the MOD folder.
local Mock = {}
local compile = loadstring or load
local dummy_source = [[
    return function(world)
        local original = Game.update
        Game.update = function(...)
            world.registered_calls = world.registered_calls + 1
            return original(...)
        end
    end
]]

function Mock.new(options)
    options = options or {}
    _G.BalatroFrameGuard_runtime = nil
    local world = {
        now = 10, delta = 1 / 60, reads = 0, writes = 0, registered_calls = 0,
        events = {}, trace = {}, mods = {}, last_hand = {}, money = 4,
        costs = {update = 0.005, event = 0.010, blind = 0.023, draw = 0.007, score = 0.012}
    }
    local function trace(name)
        world.trace[#world.trace + 1] = name
    end
    local function advance(cost)
        world.now = world.now + cost
    end
    local function queue(fn)
        world.events[#world.events + 1] = fn
    end

    G = {
        VERSION = "1.0.1o-FULL", FUNCS = {}, SETTINGS = {language = "ja"},
        STATES = {DRAW_TO_HAND = 2}, UIT = {R = 1, C = 2, T = 3, ROOT = 4},
        C = {UI = {TEXT_LIGHT = {}}, CLEAR = {}, RED = {}}
    }
    function create_toggle(args) return {toggle = args} end
    function create_option_cycle(args) return {cycle = args} end
    function UIBox_button(args) return {button = args} end

    Blind = {set_blind = function(_, blind)
        advance(world.costs.blind)
        trace("blind")
        world.blind = blind and blind.label or world.blind
    end}
    function new_round()
        trace("schedule-round")
        queue(function()
            Blind:set_blind({label = "Small"})
            queue(function()
                G.STATE = G.STATES.DRAW_TO_HAND
                G.FUNCS.draw_from_deck_to_hand()
            end)
        end)
    end
    G.FUNCS.select_blind = function()
        trace("select")
        queue(function() new_round() end)
    end
    G.FUNCS.draw_from_deck_to_hand = function()
        advance(world.costs.draw)
        trace("draw")
        world.last_hand = {math.random(13), math.random(13)}
    end
    G.FUNCS.toggle_shop = function()
        trace("leave-shop")
        world.shop = false
    end
    G.FUNCS.evaluate_play = function(mult)
        advance(world.costs.score)
        trace("score")
        world.score = (world.last_hand[1] + world.last_hand[2]) * mult
        world.money = world.money + 2
        return world.score, nil, "done", nil
    end
    EventManager = {update = function()
        advance(world.costs.event)
        local fn = table.remove(world.events, 1)
        if fn then fn() end
    end}
    Game = {
        update_shop = function()
            world.shop_ticks = (world.shop_ticks or 0) + 1
        end,
        main_menu = function() trace("menu") end,
        update = function(self, dt)
            advance(world.costs.update)
            world.forwarded_dt = dt
            EventManager:update(dt, nil)
            if world.shop then self:update_shop(dt) end
            return nil, "game", nil
        end
    }
    love = {
        timer = {
            getTime = function()
                world.reads = world.reads + 1
                return world.now
            end,
            getDelta = function() return world.delta end
        },
        update = function(...) return Game:update(...) end,
        filesystem = {write = function(name, content)
            world.writes = world.writes + 1
            world.report_name, world.report = name, content
            return true
        end}
    }
    if options.no_clock then love.timer.getTime = nil end
    if options.no_delta then love.timer.getDelta = nil end

    local function add_mod(id, version)
        local mod = {id = id, version = version, can_load = true, path = "C:/private/USER_HOME/Mods/"}
        world.mods[#world.mods + 1] = mod
        return mod
    end
    for i = 1, options.mod_count or 0 do
        local other = add_mod(("MockMod%02d"):format(i), "1.0.0")
        other.load = assert(compile(dummy_source, "@" .. other.id .. ".lua"))()
        other.load(world)
    end
    local mod = add_mod("BalatroFrameGuard", "0.2.1")
    mod.config = options.config or dofile("config.lua")
    SMODS = {
        version = "26.1002.0", current_mod = mod, mod_list = world.mods,
        load_file = function(path) return loadfile(path) end
    }
    world.mod, world.filesystem = mod, love.filesystem
    world.originals = {
        love_update = love.update, game_update = Game.update, select = G.FUNCS.select_blind
    }
    world.advance, world.queue, world.add_mod = advance, queue, add_mod

    function world:load()
        dofile("main.lua")
        self.runtime = BalatroFrameGuard_runtime.runtime
        return self.runtime
    end
    function world:tick(raw_dt, game_dt)
        self.delta = raw_dt or 1 / 60
        advance(self.delta)
        return love.update(game_dt or 0.016)
    end
    function world:progress()
        math.randomseed(4173)
        Game:main_menu()
        self.shop = true
        self:tick()
        G.FUNCS.toggle_shop()
        G.blind_select = {}
        G.FUNCS.select_blind()
        for i = 1, 3 do self:tick() end
        self.queue(function() G.FUNCS.evaluate_play(10) end)
        self:tick()
        -- Compare game-observable values and the next RNG value in the fixture.
        return table.concat({
            table.concat(self.trace, ","), self.blind, table.concat(self.last_hand, ","),
            self.score, self.money, math.random(1000000)
        }, "|")
    end
    function world:write_report()
        self.mod.config_tab()
        G.FUNCS.bfg_frameguard_report()
        return self.report
    end
    return world
end

return Mock

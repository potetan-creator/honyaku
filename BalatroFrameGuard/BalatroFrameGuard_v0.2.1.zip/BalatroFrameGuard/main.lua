local mod = SMODS.current_mod
if not mod or mod.id ~= "BalatroFrameGuard" then return end

-- SMODS does not promise a reversible hot reload for global/class function hooks.
local key = "BalatroFrameGuard_runtime"
local previous = rawget(_G, key)
if previous then
    if previous.mod ~= mod then
        previous.runtime:set_enabled(false)
        if previous.crt then previous.crt:set_enabled(false) end
    end
    return
end

local timer = type(love) == "table" and type(love.timer) == "table" and love.timer or {}
local entry_time
if type(timer.getTime) == "function" then
    local ok, value = pcall(timer.getTime)
    if ok and type(value) == "number" and value >= 0 and value < math.huge then entry_time = value end
end

local function load_module(path)
    return assert(SMODS.load_file(path))()
end

local defaults = load_module("config.lua")
local Settings = load_module("src/settings.lua")
local Metrics = load_module("src/metrics.lua")
local Hooks = load_module("src/hooks.lua")
local Runtime = load_module("src/runtime.lua")
local Crt = load_module("src/crt.lua")
local Reports = load_module("src/reports.lua")
local UI = load_module("src/ui.lua")

local ui_text = {
    ja = load_module("localization/ja.lua"),
    en = load_module("localization/en-us.lua")
}
local config = type(mod.config) == "table" and mod.config or {}
mod.config = config
Settings.normalize(config, defaults)
local runtime = Runtime.new(config, Metrics, Hooks, timer, entry_time)
local crt = Crt.new(SMODS)
local report = Reports.new(runtime, mod, SMODS, crt)
UI.install(mod, runtime, report, crt, ui_text)
rawset(_G, key, {mod = mod, runtime = runtime, crt = crt})
crt:set_enabled(config.disable_crt_in_run)
runtime:set_enabled(config.enable_monitoring)
runtime.startup.main_ready = runtime:now()

local UI = {}

local names = {
    report = "bfg_frameguard_report",
    reset = "bfg_frameguard_reset",
    threshold = "bfg_frameguard_threshold"
}

local allowed_thresholds = {slow_update_ms = true, large_frame_gap_ms = true}

local function localization(texts)
    local settings = G.SETTINGS or {}
    local language = settings.real_language or settings.language
    local file = language == "ja" and texts.ja or texts.en
    return file.misc.dictionary
end

local function status(runtime, text)
    runtime.hooks:audit()
    if not runtime.config.enable_monitoring then return text.bfg_disabled end
    if not runtime.active then return text.bfg_no_clock end
    local active, total, stopped = 0, #runtime.hooks.entries, 0
    for _, entry in ipairs(runtime.hooks.entries) do
        if entry.status == "active" then active = active + 1 end
        if entry.status == "conflict" or entry.status == "fault" then stopped = stopped + 1 end
    end
    return text.bfg_active:format(active, total, stopped)
end

function UI.install(mod, runtime, report, crt, texts)
    local config = mod.config
    local view = {message = "", status = "", crt = ""}
    local function update_status(text)
        view.status = status(runtime, text)
        view.crt = text["bfg_crt_" .. crt:status()]
    end
    local callbacks = {
        report = function()
            local text = localization(texts)
            view.message = report:write() and text.bfg_report_ok or text.bfg_report_fail
            update_status(text)
        end,
        reset = function()
            runtime:reset()
            local text = localization(texts)
            view.message = text.bfg_reset_ok
            update_status(text)
        end,
        threshold = function(args)
            if type(args) ~= "table" or type(args.cycle_config) ~= "table" then return end
            local key = args.cycle_config.bfg_config_key
            local value = tonumber(args.to_val)
            if allowed_thresholds[key] and value and value >= 1 and value <= 10000 then
                config[key] = value
            end
        end
    }

    mod.config_tab = function()
        local text = localization(texts)
        update_status(text)
        local available = {}
        for name, fn in pairs(callbacks) do
            local key = names[name]
            if G.FUNCS[key] == nil then G.FUNCS[key] = fn end
            available[name] = G.FUNCS[key] == fn
        end

        local function row(nodes)
            return {n = G.UIT.R, config = {align = "cm", padding = 0.05}, nodes = nodes}
        end
        local function label(value, key)
            return {n = G.UIT.T, config = {
                text = value, ref_table = key and view or nil, ref_value = key,
                scale = 0.29, colour = G.C.UI.TEXT_LIGHT
            }}
        end
        local function cycle(key, title, options)
            local current = config[key]
            local index
            for i, val in ipairs(options) do
                if tonumber(val) == current then index = i end
            end
            if not index then
                options[#options + 1] = tostring(current)
                index = #options
            end
            return create_option_cycle({
                label = title, options = options, current_option = index,
                opt_callback = names.threshold, bfg_config_key = key,
                no_pips = true, scale = 0.75, w = 3, h = 0.5
            })
        end
        local function button(name, title)
            return UIBox_button({
                col = true, button = names[name], label = {title},
                colour = G.C.RED, minw = 3.25, minh = 0.55, scale = 0.32
            })
        end

        local nodes = {}
        local has_toggle = type(create_toggle) == "function"
        local has_cycle = type(create_option_cycle) == "function"
        local has_button = type(UIBox_button) == "function"
        if has_toggle then
            nodes[#nodes + 1] = create_toggle({
                label = text.bfg_monitor, w = 4.2, ref_table = config, ref_value = "enable_monitoring",
                callback = function(enabled)
                    runtime:set_enabled(enabled)
                    update_status(text)
                end
            })
        end
        nodes[#nodes + 1] = row({label(nil, "status")})
        if has_toggle then
            nodes[#nodes + 1] = create_toggle({
                label = text.bfg_crt, w = 4.2, ref_table = config, ref_value = "disable_crt_in_run",
                callback = function(enabled)
                    crt:set_enabled(enabled)
                    update_status(text)
                end
            })
        end
        nodes[#nodes + 1] = row({label(nil, "crt")})
        nodes[#nodes + 1] = row({label(text.bfg_gc .. " / " .. text.bfg_cache)})
        if available.threshold and has_cycle then
            nodes[#nodes + 1] = row({
                {n = G.UIT.C, config = {align = "cm"}, nodes = {cycle("slow_update_ms", text.bfg_update_threshold, {"16.7", "25", "40", "70", "100"})}},
                {n = G.UIT.C, config = {align = "cm"}, nodes = {cycle("large_frame_gap_ms", text.bfg_gap_threshold, {"25", "40", "70", "100", "150"})}}
            })
        end

        local buttons = {}
        if has_button and available.report then buttons[#buttons + 1] = button("report", text.bfg_report) end
        if has_button and available.reset then buttons[#buttons + 1] = button("reset", text.bfg_reset) end
        if #buttons > 0 then nodes[#nodes + 1] = row(buttons) end
        if not available.report or not available.reset or not available.threshold then
            nodes[#nodes + 1] = row({label(text.bfg_ui_conflict)})
        end
        if not has_toggle or not has_cycle or not has_button then
            nodes[#nodes + 1] = row({label(text.bfg_ui_unavailable)})
        end
        nodes[#nodes + 1] = row({label(nil, "message")})
        return {n = G.UIT.ROOT, config = {align = "cm", padding = 0.12, colour = G.C.CLEAR}, nodes = nodes}
    end
end

return UI

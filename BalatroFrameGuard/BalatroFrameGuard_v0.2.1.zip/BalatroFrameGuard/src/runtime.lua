local Runtime = {}
Runtime.__index = Runtime

local function table_value(value)
    if type(value) == "table" then return value end
end

local function global_table(key)
    return function() return table_value(rawget(_G, key)) end
end

local function game()
    return table_value(rawget(_G, "G"))
end

local function callbacks()
    local g = game()
    return g and table_value(rawget(g, "FUNCS"))
end

local love_table = global_table("love")
local game_class = global_table("Game")
local specifications = {
    {id = "love_update", owner = love_table, key = "update", label = "love.update"},
    {id = "love_draw", owner = love_table, key = "draw", label = "love.draw"},
    {id = "game_update", owner = game_class, key = "update", label = "Game:update"},
    {id = "events", owner = global_table("EventManager"), key = "update", label = "EventManager:update"},
    {id = "blind_select", owner = callbacks, key = "select_blind", label = "G.FUNCS.select_blind"},
    {id = "new_round", owner = function() return _G end, key = "new_round", label = "new_round"},
    {id = "blind_set", owner = global_table("Blind"), key = "set_blind", label = "Blind:set_blind"},
    {id = "draw_dispatch", owner = callbacks, key = "draw_from_deck_to_hand", label = "G.FUNCS.draw_from_deck_to_hand"},
    {id = "shop_update", owner = game_class, key = "update_shop", label = "Game:update_shop"},
    {id = "shop_leave", owner = callbacks, key = "toggle_shop", label = "G.FUNCS.toggle_shop"},
    {id = "score", owner = callbacks, key = "evaluate_play", label = "G.FUNCS.evaluate_play"},
    {id = "menu", owner = game_class, key = "main_menu", label = "Game:main_menu"}
}

local function valid_number(value)
    return type(value) == "number" and value == value and value >= 0 and value < math.huge
end

local function read_number(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn, ...)
    if ok and valid_number(value) then return value end
end

function Runtime.new(config, metrics_class, hooks_class, timer, entry_time)
    local self = setmetatable({
        config = config, metrics_class = metrics_class, generation = 0,
        timer = timer, entry_time = entry_time, last_time = entry_time,
        clock_status = entry_time and "active" or "unsupported",
        delta_status = type(timer.getDelta) == "function" and "active" or "unsupported",
        memory_status = type(collectgarbage) == "function" and "active" or "unsupported",
        active = false, startup = {monitor_requested_at_entry = config.enable_monitoring}
    }, Runtime)
    self.hooks = hooks_class.new(self, specifications)
    self:reset()
    return self
end

function Runtime:clear_scope()
    self.generation = self.generation + 1
    self.prior_frame, self.next_audit, self.next_heap = nil, 0, 0
    self.transition_start, self.transition_kind = nil, nil
    self.set_seen, self.draw_seen = false, false
    self.update_open, self.child_depth, self.covered_ms = false, 0, 0
    self.coverage_incomplete = false
end

function Runtime:reset()
    self:clear_scope()
    self.metrics = self.metrics_class.new(self.config, specifications)
end

function Runtime:set_enabled(enabled)
    if self.active == enabled then return end
    self.hooks:audit()
    self:clear_scope()
    self.active = enabled and self.clock_status == "active"
    if self.active then
        self.hooks:enable()
    else
        self.hooks:disable()
    end
end

function Runtime:now()
    if self.clock_status ~= "active" then return nil end
    local now = read_number(self.timer.getTime)
    if not now or now < self.last_time then
        self.clock_status = "fault"
        self:set_enabled(false)
        return nil
    end
    self.last_time = now
    return now
end

function Runtime:in_blind_window(now)
    return self.transition_start ~= nil and now >= self.transition_start
        and now - self.transition_start <= self.config.blind_window_seconds
end

function Runtime:overlaps_blind_window(start, finish)
    return self.transition_start ~= nil and finish >= self.transition_start
        and start - self.transition_start <= self.config.blind_window_seconds
end

function Runtime:new_blind_window(now, kind)
    self.transition_start, self.transition_kind = now, kind
    self.set_seen, self.draw_seen = false, false
    local metrics = self.metrics
    metrics.blind_windows = metrics.blind_windows + 1
    if kind == "selection" then
        metrics.blind_selections = metrics.blind_selections + 1
    else
        metrics.blind_fallbacks = metrics.blind_fallbacks + 1
    end
end

function Runtime:skip(entry, field)
    local point = self.metrics.points[entry.spec.id]
    point[field] = point[field] + 1
end

function Runtime:instrumentation_failed(entry, generation)
    if generation ~= self.generation then return end
    if entry.spec.id == "game_update" then
        self.update_open, self.child_depth = false, 0
    elseif self.update_open then
        if entry.child then self.child_depth = math.max(0, self.child_depth - 1) end
        self.coverage_incomplete = true
    end
end

function Runtime:before(entry, first, second, third, fourth)
    local now = self:now()
    if not now then return nil end
    local id = entry.spec.id
    entry.child, entry.marker = false, false

    if id == "love_update" then
        self.startup.first_update = self.startup.first_update or now
        entry.game_dt = valid_number(first) and first or nil
        entry.raw_delta = nil
        if self.delta_status == "active" then
            entry.raw_delta = read_number(self.timer.getDelta)
            if not entry.raw_delta then self.delta_status = "fault" end
        end
    elseif id == "game_update" then
        self.update_open, self.child_depth, self.covered_ms = true, 0, 0
        self.coverage_incomplete = false
    else
        if self.update_open then
            entry.child = true
            self.child_depth = self.child_depth + 1
        end
        if id == "blind_select" then
            local g = game()
            entry.marker = g and rawget(g, "blind_select") ~= nil
        elseif id == "blind_set" then
            entry.marker = type(second) == "table" and not third and not fourth
        elseif id == "draw_dispatch" then
            local g = game()
            local states = g and table_value(rawget(g, "STATES"))
            local draw = states and rawget(states, "DRAW_TO_HAND")
            entry.marker = draw ~= nil and rawget(g, "STATE") == draw
        end
    end

    if (id == "blind_select" and entry.marker) or (id == "blind_set" and entry.marker
            and (not self.transition_start or now - self.transition_start > 15
                or (self.set_seen and not self:in_blind_window(now)))) then
        self:new_blind_window(now, id == "blind_select" and "selection" or "blind_set")
    end
    entry.blind = self:in_blind_window(now)
    return self.generation, now
end

function Runtime:update_markers(entry, start)
    if not entry.marker or not self.transition_start or start < self.transition_start
            or start - self.transition_start > 15 then return end
    local id, metrics = entry.spec.id, self.metrics
    if id == "blind_set" and not self.set_seen then
        self.set_seen = true
        metrics.blind_sets = metrics.blind_sets + 1
        if self.transition_kind == "selection" then
            metrics.blind_set_latency:add((start - self.transition_start) * 1000)
        end
    elseif id == "draw_dispatch" and not self.draw_seen then
        self.draw_seen = true
        metrics.blind_draws = metrics.blind_draws + 1
        if self.transition_kind == "selection" then
            metrics.blind_draw_latency:add((start - self.transition_start) * 1000)
        end
    end
end

function Runtime:sample_heap(now)
    if self.memory_status ~= "active" then return end
    local kib = read_number(collectgarbage, "count")
    if kib then
        self.metrics:heap(kib, now - self.entry_time)
    else
        self.memory_status = "fault"
    end
end

function Runtime:after_frame(entry, start, now, blind)
    local metrics = self.metrics
    if entry.game_dt then metrics.game_dt:add(entry.game_dt * 1000) end
    if entry.raw_delta then
        local in_window = blind or self:overlaps_blind_window(start - entry.raw_delta, start)
        metrics:gap("frame_gap", entry.raw_delta * 1000, start - self.entry_time, in_window)
    elseif self.prior_frame then
        local in_window = blind or self:overlaps_blind_window(self.prior_frame, start)
        metrics:gap("fallback_gap", (start - self.prior_frame) * 1000, start - self.entry_time, in_window)
    else
        metrics.dropped_gaps = metrics.dropped_gaps + 1
    end
    self.prior_frame = start
    if now >= self.next_audit then
        self.next_audit = now + 1
        self.hooks:audit()
    end
    if now >= self.next_heap then
        self.next_heap = now + 1
        self:sample_heap(now)
    end
end

function Runtime:after(entry, generation, start, success)
    if generation ~= self.generation then return end
    local now = self:now()
    if not now then return end
    local id, metrics = entry.spec.id, self.metrics
    local duration = (now - start) * 1000

    if entry.child then
        self.child_depth = self.child_depth - 1
        if self.child_depth == 0 then self.covered_ms = self.covered_ms + duration end
    end
    if id == "game_update" then
        if success and not self.coverage_incomplete then metrics:cover(duration, self.covered_ms) end
        self.update_open, self.child_depth = false, 0
    end
    if not success then
        self:skip(entry, "errors")
        if id == "love_update" then
            metrics.failed_updates = metrics.failed_updates + 1
            self.prior_frame = nil
        end
        return
    end

    local blind = entry.blind or self:overlaps_blind_window(start, now)
    metrics:call(id, duration, start - self.entry_time, blind)
    self:update_markers(entry, start)
    if id == "love_update" then
        self:after_frame(entry, start, now, blind)
    elseif id == "menu" then
        self.startup.menu_end = self.startup.menu_end or now
    end
end

return Runtime

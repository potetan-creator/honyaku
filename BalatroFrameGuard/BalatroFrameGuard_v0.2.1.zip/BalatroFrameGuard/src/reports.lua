local Reports = {}
Reports.__index = Reports
Reports.filename = "frameguard-report.txt"

local status_labels = {
    active = "active", disabled = "disabled", unsupported = "environment unsupported",
    conflict = "stopped (replacement detected)", fault = "stopped (instrumentation fault)"
}

local series_names = {
    {"frame_gap", "LÖVE raw frame interval"},
    {"fallback_gap", "Fallback interval between love.update calls"},
    {"game_dt", "dt passed to love.update (game input)"},
    {"update", "Game:update elapsed"},
    {"draw", "love.draw elapsed (CPU-side, excludes present)"},
    {"blind_gap", "Blind window | LÖVE raw frame interval"},
    {"blind_fallback_gap", "Blind window | fallback interval"},
    {"blind_update", "Blind window | Game:update elapsed"},
    {"blind_draw", "Blind window | love.draw elapsed"},
    {"blind_set_latency", "Blind selection to fresh set_blind call"},
    {"blind_draw_latency", "Blind selection to first draw dispatch call"}
}

local function identifier(value)
    if type(value) == "string" and #value <= 120 and value:match("^[%w_%.%+%~%-]+$") then
        return value
    end
    return "unknown"
end

local function number(value)
    return value and string.format("%.3f", value) or "n/a"
end

local function report_series(add, label, series)
    local count, sum, max, n, p50, p95, p99 = series:summary()
    add("%s | count=%d mean=%s max=%s | recent_n=%d p50=%s p95=%s p99=%s",
        label, count, number(count > 0 and sum / count or nil),
        number(count > 0 and max or nil), n, number(p50), number(p95), number(p99))
end

local function enabled_mods(add, smods)
    add("")
    add("Enabled mods (ID and version only)")
    if type(smods.mod_list) ~= "table" then
        add("Unavailable")
        return
    end
    local rows = {}
    for _, mod in ipairs(smods.mod_list) do
        if type(mod) == "table" and mod.can_load and not mod.disabled then
            rows[#rows + 1] = identifier(mod.id) .. " " .. identifier(mod.version)
        end
    end
    table.sort(rows)
    add("Count=%d (Steamodded registry)", #rows)
    for _, row in ipairs(rows) do add("%s", row) end
end

function Reports.new(runtime, mod, smods, crt)
    return setmetatable({runtime = runtime, mod = mod, smods = smods, crt = crt}, Reports)
end

function Reports:build()
    local runtime = self.runtime
    runtime.hooks:audit()
    local now = runtime:now()
    local metrics, config = runtime.metrics, runtime.config
    local lines = {}
    local function add(format, ...)
        lines[#lines + 1] = string.format(format, ...)
    end
    add("Balatro FrameGuard %s", identifier(self.mod.version))
    add("Balatro=%s | Steamodded=%s", identifier(G and G.VERSION),
        identifier(self.smods.version or MODDED_VERSION))
    add("Times +s use FrameGuard main.lua entry as zero. This is a late startup marker.")
    add("Export +s=%s | Main ready +s=%s | First observed love.update +s=%s | First observed main_menu return +s=%s",
        number(now and now - runtime.entry_time),
        number(runtime.startup.main_ready and runtime.startup.main_ready - runtime.entry_time),
        number(runtime.startup.first_update and runtime.startup.first_update - runtime.entry_time),
        number(runtime.startup.menu_end and runtime.startup.menu_end - runtime.entry_time))
    add("Monitoring requested at entry=%s. First observed markers depend on when monitoring was enabled.",
        tostring(runtime.startup.monitor_requested_at_entry))
    add("Menu return is a Lua boundary.")
    add("Monitoring requested=%s | running=%s | monotonic clock=%s | getDelta=%s",
        tostring(config.enable_monitoring), tostring(runtime.active), status_labels[runtime.clock_status],
        status_labels[runtime.delta_status])
    add("CRT bypass requested=%s | state=%s | run frames bypassed since startup=%d",
        tostring(config.disable_crt_in_run), status_labels[self.crt:status()], self.crt.bypassed)
    add("GC step tuning=unavailable (disabled) | Optional cache=unavailable (disabled)")
    add("Thresholds: update > %.3f ms, frame gap > %.3f ms | recent event limit=%d | frame ring=%d",
        config.slow_update_ms, config.large_frame_gap_ms, config.max_events, config.frame_samples)
    add("Blind window=%.3f s | windows=%d (selection=%d set fallback=%d) | fresh set markers=%d | first draw markers=%d",
        config.blind_window_seconds, metrics.blind_windows, metrics.blind_selections,
        metrics.blind_fallbacks, metrics.blind_sets, metrics.blind_draws)
    add("Marker latency is wall time, including intentional animation/event delays. Pairing expires after 15 s.")
    add("A draw marker is dispatch of draw work, not completion of the animation.")
    add("")
    add("Frame timing and marker latency (ms)")
    add("Count/mean/max cover the session since reset. Percentiles use bounded recent samples and nearest rank.")
    add("Frame intervals can include draw/present waits, sleep and scheduling. They cannot isolate GPU load.")
    add("Update times measure elapsed wall time around CPU-side work, including waits and profiler overhead.")
    add("Raw frame interval and fallback interval are separate series. Game input dt may be smoothed/clamped.")
    add("Failed outer updates=%d | Missing interval without fallback=%d", metrics.failed_updates, metrics.dropped_gaps)
    for _, item in ipairs(series_names) do report_series(add, item[2], metrics[item[1]]) end

    local coverage = metrics.coverage
    add("")
    add("Game:update coverage")
    add("Successful calls with coverage=%d | total_ms=%.3f | covered_union_ms=%.3f | other_inside_update_ms=%.3f",
        coverage.count, coverage.sum, coverage.covered, coverage.uncovered)
    add("Coverage is the union of observed child calls started inside Game:update. Draw/present and time")
    add("outside Game:update are outside this accounting. A missing or replaced hook reduces observed coverage.")

    local sorted = {}
    for i, entry in ipairs(runtime.hooks.entries) do sorted[i] = entry end
    table.sort(sorted, function(a, b)
        local left, right = metrics.points[a.spec.id], metrics.points[b.spec.id]
        if left.sum == right.sum then return a.spec.id < b.spec.id end
        return left.sum > right.sum
    end)
    add("")
    add("Call boundaries, sorted by inclusive total elapsed time")
    add("These rows can overlap. The direct cause and responsible mod are unknown from boundary timing alone.")
    add("Call counts exclude original errors, same-hook recursion and coroutine calls. EventManager:update counts")
    add("passes through the manager. It does not count events or identify individual event callbacks.")
    for _, entry in ipairs(sorted) do
        local point = metrics.points[entry.spec.id]
        add("%s [%s] | calls=%d total_ms=%.3f max_ms=%s | blind_calls=%d blind_total_ms=%.3f blind_max_ms=%s | errors=%d co_skips=%d reentry_skips=%d",
            entry.spec.label, status_labels[entry.status], point.count, point.sum,
            number(point.count > 0 and point.max or nil), point.blind_count, point.blind_sum,
            number(point.blind_count > 0 and point.blind_max or nil),
            point.errors, point.coroutine_skips, point.recursive_skips)
        if point.last_slow_time then
            add("  latest slow: +%.3fs %.3fms (threshold %.3fms) blind=%s",
                point.last_slow_time, point.last_slow_ms, point.last_slow_threshold, tostring(point.last_slow_blind))
        end
    end

    local memory = metrics.memory
    add("")
    add("Lua heap | status=%s | samples=%d | first/min/max/latest KiB=%s/%s/%s/%s | latest +s=%s",
        status_labels[runtime.memory_status], memory.count, number(memory.first),
        number(memory.min), number(memory.max), number(memory.last), number(memory.time))
    add("Heap is the Lua VM's count, sampled roughly once per second during observed updates.")
    add("It excludes process RSS, native assets and GPU memory.")

    add("")
    add("Recent slow observations (newest first)")
    for offset = 1, #metrics.recent do
        local index = (metrics.recent_next - 1 - offset) % config.max_events + 1
        local row = metrics.recent[index]
        local hook = runtime.hooks.by_id[row.id]
        add("+%.3fs | %s | %.3fms (threshold %.3fms) | blind=%s", row.time,
            hook and hook.spec.label or row.id, row.ms, row.threshold, tostring(row.blind))
    end

    enabled_mods(add, self.smods)
    return table.concat(lines, "\n") .. "\n"
end

function Reports:write()
    local filesystem = love and love.filesystem
    if type(filesystem) ~= "table" or type(filesystem.write) ~= "function" then return false end
    local ok, result = pcall(function()
        return filesystem.write(self.filename, self:build())
    end)
    return ok and result == true
end

return Reports

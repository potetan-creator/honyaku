local Settings = {}

local function number(value, default, lower, upper)
    if type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then
        return default
    end
    return math.max(lower, math.min(upper, value))
end

function Settings.normalize(config, defaults)
    if type(config.enable_monitoring) ~= "boolean" then
        config.enable_monitoring = defaults.enable_monitoring
    end
    config.slow_update_ms = number(config.slow_update_ms, defaults.slow_update_ms, 1, 10000)
    config.large_frame_gap_ms = number(config.large_frame_gap_ms, defaults.large_frame_gap_ms, 1, 10000)
    config.max_events = math.floor(number(config.max_events, defaults.max_events, 1, 1000))
    config.frame_samples = math.floor(number(config.frame_samples, defaults.frame_samples, 128, 16384))
    config.blind_window_seconds = number(config.blind_window_seconds, defaults.blind_window_seconds, 0.25, 15)
    if type(config.disable_crt_in_run) ~= "boolean" then
        config.disable_crt_in_run = defaults.disable_crt_in_run
    end
    config.enable_gc_tuning = false
    config.enable_optional_cache = false
end

return Settings

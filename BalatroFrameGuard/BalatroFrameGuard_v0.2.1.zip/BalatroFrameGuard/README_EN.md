# Balatro FrameGuard v0.2.1

A diagnostics mod for Windows Balatro with Lovely and Steamodded. It measures frame intervals, update and event boundaries, blind transitions, and Lua heap use. It also offers an opt-in setting to skip the built-in CRT pass during runs. Gameplay and boot performance gains have not been verified.

## Install and use

1. Exit the game and extract the ZIP.
2. Put the enclosed `BalatroFrameGuard` folder in `%APPDATA%\Balatro\Mods\`. The JSON metadata should be directly inside that folder.
3. If upgrading, replace the existing FrameGuard folder while the game is closed.
4. Launch Balatro and open **Mods → Balatro FrameGuard → Config**. The menu supports Japanese and English. No additional DLL or service is required.

Monitoring defaults to ON. Use **Enable monitoring** to detach or restore FrameGuard's own hooks during play. **Reset metrics** clears the current measurements and keeps the startup markers. **Save report** exports or replaces `frameguard-report.txt` in Balatro's LÖVE save directory, typically `%APPDATA%\Balatro\`. The report includes mod IDs and versions from the registry. It excludes paths and save contents.

The independent defaults are 40 ms for calls and 70 ms for frame gaps. Change these limits in the config menu. GC tuning and the optional cache have separate unavailable statuses. Neither tuning method runs.

## Skip CRT during runs

**Skip CRT during runs** is off by default and operates independently of monitoring. It removes Steamodded's built-in CRT pass during gameplay. CRT distortion, scanlines and bloom can change visually. Menus and recording modes use the regular pipeline. The setting targets Balatro 1.0.1o with Steamodded 26.1002.0 and disables itself if it detects additional full-screen shaders or a modified CRT callback. It can reduce rendering work. It does not change the amount of work in scoring or event callbacks.

## Read the report

- **LÖVE raw frame interval** uses the last `love.timer.step()` interval. It can include rendering, presentation waits and scheduling. The fallback records time between update calls in its own series. The game's smoothed input `dt` is also shown separately.
- **Game:update elapsed** is wall time around CPU-side update work. It includes waits and profiler overhead. Coverage uses the union of observed nested intervals inside `Game:update`. The boundary totals can overlap.
- **love.draw elapsed** measures CPU-side wall time around draw, before presentation. It reports no direct GPU duration.
- **Blind window** starts on selection, with new blind setup as a fallback, and covers two seconds by default. The setup and draw markers measure invocation boundaries. Draw dispatch can schedule work for later frames.
- Memory is the sampled Lua heap. The report has no process RSS, native asset totals or GPU timings.
- Counts, means and maxima describe the session since reset. Percentiles use bounded recent samples and report their sample sizes. The direct cause of a slow boundary and the responsible mod remain unknown.
- Startup measurements start at FrameGuard's Lua entry, after early loading has already begun. Earlier stages can be investigated with external timings and the existing Lovely and Steamodded logs.

Steamodded merges `config.lua` defaults with its own saved per-mod config. Changing the ring sizes or blind window takes a restart. Game errors are rethrown with the same error value. The original traceback may be shortened. Coroutine invocations and same-hook recursion bypass timing. Missing hooks or replacements are shown in the report. A full restart is needed after updating FrameGuard or clearing runtime conflicts. To uninstall, exit and remove the mod folder. The report and Steamodded per-mod config can be removed separately.

Steamodded 26.1002.0, Balatro 1.0.1o source and the LÖVE 11.5 timer implementation were reviewed. Gameplay, coexistence with real mods and performance on the intended Windows hardware remain untested. See [TEST_PLAN.md](TEST_PLAN.md), [BENCHMARK_RESULTS.md](BENCHMARK_RESULTS.md) and the [Japanese README](README_JA.md).

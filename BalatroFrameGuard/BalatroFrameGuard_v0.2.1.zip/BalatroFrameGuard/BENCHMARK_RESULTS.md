# Balatro FrameGuard v0.2.1 検証結果

## 確認結果

| 区分 | 結果 |
| --- | --- |
| 静的検証 | Luaファイル16本の構文をLuaJITで検証。JSONの必須フィールド、単一のメタデータ、ZIPの階層・CRC・内容を確認。 |
| モック動作 | LuaJIT 2.1.1795119671とLua 5.3でそれぞれ25件合格。通常の進行を模したテストと、50本の模擬Lua MODをロードしたケースを含む。 |
| Steamodded描画コードの確認 | Steamodded 26.1002.0の描画パッチのLuaをスタブ環境で実行し、CRT省略のON/OFFで処理が切り替わることを確認。 |
| モックの一致確認 | 同一シード・同一操作のイベント順序、スコア、カード、所持金、次の乱数が一致。これはテスト用の小さなゲーム状態についての結果。 |
| 安全停止 | 診断OFFで元の関数を復元。後続MODの再定義は保持し、対象境界だけ停止。Lua例外、欠落API、時計異常、書き出し失敗、リング上限を模擬して確認。 |
| Windows版の実ゲーム | 本体と実MOD環境を利用できず未実施。実際のMOD認識と設定の表示・永続化、起動、ブラインド、ショップ、スコア、セーブ・再開は未確認。 |
| 対象PCでの性能 | Core i5-9400F / 16GB / GTX 1660 SUPERで未計測。FPS、起動秒数、ブラインド突入時間の改善は未確認。 |

LuaJITとLua 5.3の出力は [tests/mock-test-results.txt](tests/mock-test-results.txt) に収録しました。50本は独立したダミーLuaチャンクと関数ラッパーです。実MODのアセット読み込み、SMODS本体のロード負荷、セーブ処理はこのモックの対象外です。

## ラン中のCRT描画

Steamodded 26.1002.0の `ScreenShader` には、シェーダーの適用を決める `should_apply` があります。FrameGuardは対応版の標準CRTを確認したうえで、この判定だけをラン中かつ録画・動画制御の外でOFFにします。スコア、イベント、入力、セーブに関わる処理は変更していません。追加の全画面シェーダーがある場合や、コールバック・シェーダーオブジェクトの差し替えを検出した場合はCRT省略を停止します。インストール時点ですでに改変されたGPUシェーダーのソース内容までは、この方法では判別できません。

上流と同じ描画パッチをモックで実行したところ、対象の全画面処理は描画2回・設定値送信11回から、描画1回・設定値送信0回になりました。OFFへ戻すと元の回数へ復帰しました。シーン全体の描画回数やGPUの実時間はこの試験から分かりません。 [上流の描画パッチ](https://github.com/Steamodded/smods/blob/26.1002.0/lovely/screenshader_rendering.toml) · [上流のCRTオブジェクト](https://github.com/Steamodded/smods/blob/26.1002.0/src/game_object.lua#L3536-L3585)

## 診断機能自体のモック負荷

Linux x86-64 / AMD EPYC 9V74のクラウド環境で、LuaJIT 2.1.1795119671を使用しました。CRT省略をOFFにして50本の模擬MODを登録し、各条件30万更新×5回、実行順を交替して測定しました。CPU時間はベンチマークプロセスの `os.clock()`、ヒープは同じフィクスチャを作成した後に全GCを行って得た差分です。ゲーム内計測の時計はLÖVEの `getTime()` です。

| 条件 | CPU時間 µs/更新の中央値 | 追加Luaヒープ KiBの中央値 | 30万更新当たりの計測時計呼び出し |
| --- | ---: | ---: | ---: |
| FrameGuardなし | 1.605 | 0.0 | 0 |
| FrameGuard導入、初めからOFF | 1.603 | 63.1 | 0 |
| FrameGuard導入、ON | 3.353 | 70.1 | 1,800,000 |
| FrameGuard導入、記録後にOFF | 1.590 | 192.0 | 0 |

追加ヒープの列は計時前に取得しました。ONは起動直後、記録後OFFはフレームと遅延履歴を満たしてからの値です。ONで観測した差は、このモックの更新、時計スタブ、計測処理に関する値です。この計時ループでは描画を呼び出していません。OFFと基準の小さな差は観測した試行間のばらつきに収まっており、性能向上を示すものではありません。全個別値は [tests/monitoring-overhead.csv](tests/monitoring-overhead.csv) にあります。

## 最適化と起動調査

| 候補 | 観測 | 採用判断 |
| --- | --- | --- |
| 追加GCステップ | 参照したBalatro 1.0.1oでは `Game:update` が `nuGC` を呼びます。既定予算内で小ステップを進め、ヒープが基準を超えると全回収し、通常の自動回収を停止する経路があります。 | 追加のGCは既存予算と実行タイミングに干渉し、かえってカクつく可能性があります。まずヒープの推移と長いCPU側更新を同条件で照合する必要があります。GC調整は未実装です。 |
| ブラインド関連キャッシュ | `set_blind` にはスプライトの更新や、SMODS経由のMOD固有コールバックが入ります。周辺では状態変更、ジョーカー計算、イベント登録・カード移動を行います。 | MOD横断で同一入力・同一出力が保証できる高負荷の純粋処理を確認できず、起動先読みの効果とメモリ費用も未測定です。キャッシュ・先読みは未実装です。 |
| スコアとイベント処理 | SpeedTweaks 0.1.0の公開ソースは `Card:calculate_joker` と `SMODS.calculate_repetitions` に介入します。Balatroはブラインド選択、設定、配布を既存イベントで進めます。 | FrameGuardはスコアの外側の `evaluate_play` と関連する処理境界を観測します。計算の短絡、キュー変更、イベント分割、乱数操作を加えていません。 |
| 起動前半の早期計測・高速化 | Steamoddedは自Modのエントリより前に探索・優先順位選定・API初期化を行います。Lovelyのパッチ適用はさらに前段です。後半でもアセット読込や登録は複数の箇所にまたがります。 | 外部計測と既存ログを使用できます。早期パッチは候補ですが、実際のパッチ対象と他MODとの順序をWindowsで検証できていません。起動前半の独自計測、統合キャッシュ、実ゲームの起動高速化は未実装です。 |

起動の後半はFrameGuardのLua開始を起点として観測できます。ブラインド突入はフレーム間隔と処理境界の集計で再現箇所を絞り込めます。どちらも、実測が揃うまでは原因を特定できません。実測の手順は [TEST_PLAN.md](TEST_PLAN.md) を参照してください。

## 互換性

| 構成 | 確認範囲 |
| --- | --- |
| Balatro + Lovely + Steamodded | Steamodded 26.1002.0、Balatro 1.0.1o参照ソース、LÖVE 11.5を静的に照合。実ゲームは未実施。 |
| 50 MOD相当、診断OFF | モックで検証。実MODの大量導入環境は未実施。 |
| SpeedTweaks | 公開コードで計算内部の対象を照合。実ゲームでの併用は未実施。 |
| Amulet / Talisman / Cryptid / Allinjest / Cafetro! / JokerDisplay | 個別・組み合わせとも実ゲーム未実施。特定MODの設定や処理分岐に対する変更は含まない。 |

MOD IDは `BalatroFrameGuard`、prefixは `bfg` を使用しました。公開検索と確認した参照元で同名の別MODは確認できませんでした。全公開・非公開MODを対象にした衝突保証はありません。

## ソース照合

- SteamoddedのJSONメタデータ、`SMODS.current_mod.config`、`config_tab`、`SMODS.load_file`、優先順位順のロード、`mod_list` と `can_load` を確認しました。参照はリリース26.1002.0（`af0fdb1`）です。 [メタデータ](https://docs.smods.dev/API%20Documentation/Mod-Metadata/) · [Mod Object](https://docs.smods.dev/API%20Documentation/The-Mod-Object/) · [Steamoddedローダー](https://github.com/Steamodded/smods/blob/26.1002.0/src/preflight/loader.lua) · [設定UIソース](https://github.com/Steamodded/smods/blob/26.1002.0/src/ui.lua)
- Balatro 1.0.1oの公開参照スナップショット（`895ab3a`、非公式公開元）とSteamoddedのLovelyパッチを照合し、更新、ブラインド選択・設定、ラウンド登録、配布要求、ショップ、採点、イベントマネージャーの境界を選びました。本体コードはZIPに含めていません。 [Balatro参照スナップショット](https://github.com/GladdonT/balatro-source-code/tree/895ab3a25bc6f513fa80885eb59951bf8e76bc55) · [Steamoddedのパッチ](https://github.com/Steamodded/smods/tree/26.1002.0/lovely)
- LÖVE 11.5のタイマーソースで `getDelta()`、`step()`、Windowsの `getTime()` が高分解能カウンターを使うことを確認しました。 [LÖVE Timer.cpp](https://github.com/love2d/love/blob/11.5/src/modules/timer/Timer.cpp)
- SpeedTweaks 0.1.0（`04fec7a`）の介入箇所とLovelyのパッチ・ログ構造を確認しました。 [SpeedTweaksの公開コード](https://github.com/kians322315/SpeedTweaks-Balatro/blob/04fec7a9b312182d6f09c0a4ecaf16021b643087/main.lua) · [Lovely公開ソース](https://github.com/ethangreen-dev/lovely-injector/tree/073060eeb81b3664f476bdd33c263663d48762d1)

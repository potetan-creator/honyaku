"""Check the mod metadata, archive contents and Lua syntax.

Run from the MOD directory. Provide --archive after creating the install ZIP.
"""
import argparse
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
from zipfile import ZipFile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lua", default="luajit", help="LuaJIT or Lua interpreter")
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()

    root = Path.cwd()
    metadata = json.loads((root / "BalatroFrameGuard.json").read_text(encoding="utf-8"))
    for key in ("id", "name", "description", "prefix", "version", "main_file"):
        assert isinstance(metadata[key], str) and metadata[key], key
    assert isinstance(metadata["author"], list) and metadata["author"]
    assert all(isinstance(author, str) and author for author in metadata["author"])
    assert isinstance(metadata["priority"], int)
    assert metadata["id"] == "BalatroFrameGuard" and metadata["prefix"] == "bfg"
    assert metadata["version"] == "0.2.1"
    assert (root / metadata["main_file"]).is_file()
    assert len(list(root.glob("*.json"))) == 1

    files = sorted(root.rglob("*.lua"))
    for path in files:
        subprocess.run(
            [args.lua, "-e", "assert(loadfile(os.getenv('BFG_LUA_CHECK_FILE')))"],
            env={**os.environ, "BFG_LUA_CHECK_FILE": str(path)},
            check=True,
        )
        assert b"--- STEAMODDED HEADER" not in path.read_bytes(), path
    print(f"PASS JSON metadata and {len(files)} Lua syntax checks")

    if args.archive:
        with ZipFile(args.archive) as archive:
            paths = [PurePosixPath(path) for path in archive.namelist()]
            assert len(paths) == len(set(paths)), "Duplicate ZIP paths"
            assert all(path.parts[0] == "BalatroFrameGuard" and ".." not in path.parts for path in paths)
            assert archive.testzip() is None
            expected = {Path("BalatroFrameGuard") / path.relative_to(root)
                        for path in root.rglob("*") if path.is_file()}
            actual = {Path(entry.filename) for entry in archive.infolist() if not entry.is_dir()}
            assert actual == expected, f"Archive paths differ: {actual ^ expected}"
            for path in actual:
                assert archive.read(path.as_posix()) == (root / path.relative_to("BalatroFrameGuard")).read_bytes()
        print(f"PASS archive CRC, structure and file contents ({len(actual)} files)")


if __name__ == "__main__":
    main()
